/* ----------------------------------------------------------------------
** Include Files
** ------------------------------------------------------------------- */
#include <project.h>
#include "arm_math.h"
#include "arm_const_structs.h"
#include "math_helper.h"


/*static q15_t hanning={ 0 * 32768,
                0.0102 * 32768,
                0.0405 * 32768,
    
                0.0896 * 32768,
                0.1555 * 32768,
                0.2355 * 32768,
                0.3263 * 32768,
                0.4243 * 32768,
                0.5253 * 32768,
                0.6253 * 32768,
                0.7202 * 32768,
                0.8061 * 32768,
                0.8794 * 32768,
                0.9372 * 32768,
                0.9771 * 32768,
                0.9974 * 32768,
                0.9974 * 32768,
                0.9771 * 32768,
                0.9372 * 32768,
                0.8794 * 32768,
                0.8061 * 32768,
                0.7202 * 32768,
                0.6253 * 32768,
                0.5253 * 32768,
                0.4243 * 32768,
                0.3263 * 32768,
                0.2355 * 32768,
                0.1555 * 32768,
                0.0896 * 32768,
                0.0405 * 32768,
                0.0102 * 32768,
                     0 * 32768};*/


/* ----------------------------------------------------------------------
 * DMA Definitions
 * ------------------------------------------------------------------- */
/*First buffer*/
uint8 DMA_1_Chan;
uint8 DMA_1_TD[1];


#define buffer_size 512
/* Definitions */
#define DMA_1_BYTES_PER_BURST 2
#define DMA_1_REQUEST_PER_BURST 1
#define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_1_DST_BASE (CYDEV_SRAM_BASE)
#define buffersize buffer_size*DMA_1_BYTES_PER_BURST
/*Second buffer*/
uint8 DMA_2_Chan;
uint8 DMA_2_TD[1];
#define DMA_2_BYTES_PER_BURST 2
#define DMA_2_REQUEST_PER_BURST 0
#define DMA_2_SRC_BASE (CYDEV_SRAM_BASE)
#define DMA_2_DST_BASE (CYDEV_SRAM_BASE)

//#define windowsize 8
/* static,extern, const declarations*/

/*global vairables*/
int16 ADC_buffer1[buffer_size];
int16 ADC_buffer2[buffer_size];
int16 ADC_buffer3[buffer_size];
int16 Buffer_samples[buffer_size];
int16 ADC_samples[buffer_size];
q15_t magoutput1[buffer_size/2];
q15_t magoutput2[buffer_size/2];
static uint32 fftlength=buffer_size/2;
static uint32 i=0;
static uint16 count=0;
static uint32 start1,end1,start2,end2;
static q15_t maxValue;
static uint32 testIndex;
static uint8 state=0x00;
static uint8 next_state=0x00;
static uint8 onset=0;
//uint32 SpectralFlux[windowsize];
uint32 SpectralFlux3;
uint32 SpectralFlux2;
uint32 SpectralFlux1;
uint16 uppersrcaddr2;
uint16 lowersrcaddr2;
uint16 upperdstaddr2;
uint16 lowerdstaddr2;
uint32 mvngaverage;

static volatile CYBIT isr_BC_flag = 0;

/*functions*/
void Configure_DMA();
//uint32 moving_average(uint32 *specflux);


/*ISR routine*/
CY_ISR(Buffer_complete){
    isr_BC_flag=1;
//    uppersrcaddr2=HI16(ADC_samples);
//    lowersrcaddr2=LO16((uint32)ADC_samples);
//    upperdstaddr2=HI16(Buffer_samples);
//    lowerdstaddr2=LO16((uint32)Buffer_samples);
    CyDmaChDisable(DMA_2_Chan);
}


/*main*/
void main(void)
{    /*Stuff from spectral flux file*/
      uint32_t srcRows=1;
      uint32_t srcColumns=buffer_size/2; 
      uint16_t fftSize = 1024;
      uint8_t ifftFlag = 0;
      uint8_t doBitReverse = 1;
      q15_t testOutput0[buffer_size/2];
      q15_t testOutput1[buffer_size/2];
      q15_t Difference[buffer_size/2];


    /*Preliminary parts not important*/  
    LCD_Char_1_Start();
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    Configure_DMA(); 
    isr_1_StartEx(Buffer_complete);
    
    CyGlobalIntEnable;
    
    /*Writes ADC values to ADC_samples array*/
    next_state=0x00;
    state=0x10;
    
    while(1){
    if (isr_BC_flag==1){        
        arm_copy_q15(Buffer_samples,ADC_buffer1,buffer_size);
        CyDmaChEnable(DMA_2_Chan, 1);
        arm_copy_q15(ADC_buffer3,ADC_buffer2,buffer_size);        
        arm_copy_q15(ADC_buffer1,ADC_buffer3,buffer_size);
//        arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer1, 0, 1); 
//        arm_cmplx_mag_q15(ADC_buffer1, magoutput1, fftlength); 
//        arm_max_q15(magoutput1, fftlength, &maxValue, &testIndex);
        isr_BC_flag=0;
        isr_1_ClearPending();
        state=next_state;
    }
    
    switch(state){
    case 0x00:  next_state=0x01;
                state=0x10;
                break;
    case 0x01:  next_state=0x02;
                state=0x10;
                
                //calculate the cfft of the testInput0 and take the absolute value   
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer1, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer1, testOutput0, fftlength);   
                //calculate the cfft of the testInput1 and take the absolute value   
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer2, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer2, testOutput1, fftlength);
               

                //perform the matrix subtraction 
//                arm_mat_sub_q15(&fftmatrix1,&fftmatrix0,&DiffMatrix); 
//                *Difference= *DiffMatrix.pData;

                for (i=0;i<buffer_size/2;i++){
                    Difference[i] = testOutput1[i]-testOutput0[i];
                }
                
                //sum up all the differences 
            	for(i=0; i< buffer_size/2; i++)
              	  {
               	    SpectralFlux3=Difference[i]+SpectralFlux3;
                    //arm_add_q15(SpectralFlux, &Difference[i], SpectralFlux, 1);
            	  }	  
                

                break;
    case 0x02:  next_state=0x03;
                state=0x10;
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer1, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer1, testOutput0, fftlength);   
                //calculate the cfft of the testInput1 and take the absolute value   
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer2, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer2, testOutput1, fftlength);
               

                //perform the matrix subtraction 
//                arm_mat_sub_q15(&fftmatrix1,&fftmatrix0,&DiffMatrix); 
//                *Difference= *DiffMatrix.pData;

                for (i=0;i<buffer_size/2;i++){
                    Difference[i] = testOutput1[i]-testOutput0[i];
                }
                // for the sake of being literal, create a pointer directly to the matrix data
                    
                //sum up all the differences 
            	for(i=0; i< buffer_size/2; i++)
              	  {
               	    SpectralFlux2=Difference[i]+SpectralFlux2;
                    //arm_add_q15(SpectralFlux, &Difference[i], SpectralFlux, 1);
            	  }                
                break;
    case 0x03:  next_state=0x03;
                state=0x10;
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer1, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer1, testOutput0, fftlength);   
                //calculate the cfft of the testInput1 and take the absolute value   
                arm_cfft_q15(&arm_cfft_sR_q15_len256, ADC_buffer2, 0, 1); 
                arm_cmplx_mag_q15(ADC_buffer2, testOutput1, fftlength);
               

                //perform the matrix subtraction 
//                arm_mat_sub_q15(&fftmatrix1,&fftmatrix0,&DiffMatrix); 
//                *Difference= *DiffMatrix.pData;

                for (i=0;i<buffer_size/2;i++){
                    Difference[i] = testOutput1[i]-testOutput0[i];
                }
                // for the sake of being literal, create a pointer directly to the matrix data
                    
                //sum up all the differences 
            	for(i=0; i< buffer_size/2; i++)
              	  {
               	    SpectralFlux1=Difference[i]+SpectralFlux1;
                    //arm_add_q15(SpectralFlux, &Difference[i], SpectralFlux, 1);
            	  }                
                //mvngaverage=moving_average(SpectralFlux);
                if (((SpectralFlux2>SpectralFlux1*100) && (SpectralFlux2>SpectralFlux3*100))) //&& (SpectralFlux2>mvngaverage))
                {
                onset=1;
                Red_LED_Write(1);
                }
                else{
                Red_LED_Write(0);
                onset=0;}
                
                
//                if (count<windowsize){
//                    count=count+1;
//                }
//                else{
//                    count=0;
//                }
                
                //SpectralFlux[count]=SpectralFlux2;
                
                SpectralFlux3=SpectralFlux2;
                SpectralFlux2=SpectralFlux1;
                LCD_Char_1_Position(0u,0u);
                LCD_Char_1_PrintString("3:");
                LCD_Char_1_PrintInt32(SpectralFlux3);
                LCD_Char_1_Position(1u,0u);
                LCD_Char_1_PrintInt32((uint16)SpectralFlux2);                
                LCD_Char_1_Position(0u,11u);
                LCD_Char_1_PrintString("2:");
                LCD_Char_1_PrintInt32((uint16)(SpectralFlux2>>16));
                LCD_Char_1_Position(1u,6u);
                LCD_Char_1_PrintString("1:");
                LCD_Char_1_PrintInt32(SpectralFlux1);   
                break;
    case 0x10:  break;//idle state 
                
    default:    state=0x10;
    }
    }
}

void Configure_DMA(){
/*Second buffer*/
DMA_2_Chan = DMA_2_DmaInitialize(DMA_2_BYTES_PER_BURST, DMA_2_REQUEST_PER_BURST, 
    HI16(DMA_2_SRC_BASE), HI16(DMA_2_DST_BASE));
DMA_2_TD[0] = CyDmaTdAllocate();
CyDmaTdSetConfiguration(DMA_2_TD[0], buffersize, DMA_2_TD[0], DMA_2__TD_TERMOUT_EN | TD_INC_SRC_ADR | TD_INC_DST_ADR);
CyDmaTdSetAddress(DMA_2_TD[0], LO16((uint32)ADC_samples), LO16((uint32)Buffer_samples));
CyDmaChSetInitialTd(DMA_2_Chan, DMA_2_TD[0]);
CyDmaChEnable(DMA_2_Chan, 1);

/*First buffer*/
DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
    HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
DMA_1_TD[0] = CyDmaTdAllocate();
CyDmaTdSetConfiguration(DMA_1_TD[0], buffersize, /*CY_DMA_DISABLE_TD */DMA_1_TD[0], DMA_1__TD_TERMOUT_EN | TD_INC_DST_ADR);
CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_DelSig_1_DEC_SAMP_PTR), LO16((uint32)ADC_samples));
CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
CyDmaChEnable(DMA_1_Chan, 1);
}

//uint32 moving_average(uint32 *specflux){
//    uint8 k=0;
//    uint32 sum=0;
//    uint32 average=0;
//    uint32 * ptr;
//    ptr=specflux;
//
//    for (k=0;k<windowsize;k++){
//        sum=sum+(*ptr);
//        ptr++;
//    }
//    average=sum/windowsize;
//    return average;
//}
//    